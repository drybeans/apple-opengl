//
//  ViewController.h
//  StonehengeES
//
//  Created by Richard Wright on 3/16/13.
//  Copyright (c) 2013 Richard Wright. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GLKit/GLKit.h>
#import "GLStonehenge.h"

@interface ViewController : GLKViewController
    {
    GLStonehenge    stoneHenge;
    }
@end
