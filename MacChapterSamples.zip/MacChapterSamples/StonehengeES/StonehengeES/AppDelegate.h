//
//  AppDelegate.h
//  StonehengeES
//
//  Created by Richard Wright on 3/16/13.
//  Copyright (c) 2013 Richard Wright. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
