//
//  AppDelegate.h
//  StonehengeCGL
//
//  Created by Richard Wright on 1/13/13.
//  Copyright (c) 2013 Richard Wright. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
