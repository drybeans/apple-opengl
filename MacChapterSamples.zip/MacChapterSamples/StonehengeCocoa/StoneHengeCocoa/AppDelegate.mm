//
//  AppDelegate.m
//  StoneHengeCocoa
//
//  Created by Richard Wright on 1/13/13.
//  Copyright (c) 2013 Richard Wright. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

- (void)dealloc
{
    [super dealloc];
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

@end
