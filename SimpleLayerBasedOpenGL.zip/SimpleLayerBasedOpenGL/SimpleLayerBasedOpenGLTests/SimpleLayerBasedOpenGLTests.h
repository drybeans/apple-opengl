//
//  SimpleLayerBasedOpenGLTests.h
//  SimpleLayerBasedOpenGLTests
//
//  Created by David Bainbridge on 8/30/12.
//  Copyright (c) 2012 David Bainbridge. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface SimpleLayerBasedOpenGLTests : SenTestCase

@end
