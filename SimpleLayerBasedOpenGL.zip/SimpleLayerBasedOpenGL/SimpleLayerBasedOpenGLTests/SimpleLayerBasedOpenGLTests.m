//
//  SimpleLayerBasedOpenGLTests.m
//  SimpleLayerBasedOpenGLTests
//
//  Created by David Bainbridge on 8/30/12.
//  Copyright (c) 2012 David Bainbridge. All rights reserved.
//

#import "SimpleLayerBasedOpenGLTests.h"

@implementation SimpleLayerBasedOpenGLTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in SimpleLayerBasedOpenGLTests");
}

@end
