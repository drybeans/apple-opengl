//
//  main.m
//  SimpleLayerBasedOpenGL
//
//  Created by David Bainbridge on 8/30/12.
//  Copyright (c) 2012 David Bainbridge. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
