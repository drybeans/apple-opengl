//
//  DBAppDelegate.m
//  SimpleLayerBasedOpenGL
//
//  Created by David Bainbridge on 8/30/12.
//  Copyright (c) 2012 David Bainbridge. All rights reserved.
//

#import "DBAppDelegate.h"

@implementation DBAppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

@end
